import { createContext } from 'react';
const SellContext = createContext();
export default SellContext;
