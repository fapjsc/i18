import { createContext } from 'react';
const HistoryContext = createContext();
export default HistoryContext;
