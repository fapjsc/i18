import { createContext } from 'react';
const InstantContext = createContext();
export default InstantContext;
