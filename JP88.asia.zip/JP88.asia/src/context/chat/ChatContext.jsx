import { createContext } from 'react';
const BalanceContext = createContext();
export default BalanceContext;
