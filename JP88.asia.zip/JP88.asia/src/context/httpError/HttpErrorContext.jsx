import { createContext } from 'react';
const HttpErrorContext = createContext();
export default HttpErrorContext;
