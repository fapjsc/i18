import { createContext } from 'react';
const BuyContext = createContext();
export default BuyContext;
