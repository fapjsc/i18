import { createContext } from 'react';
const TransferContext = createContext();
export default TransferContext;
